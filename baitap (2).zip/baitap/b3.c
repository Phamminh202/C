#include<stdio.h>
float main()
{
	float r,p,s;
	
	printf("Nhap ban kinh vong tron:");
	scanf("%f",&r);
	
	p=r*3.141592*2;
	printf("Chu vi la:%f\n",p);
	s=r*r*3.141592;
	printf("Dien tich la:%f\n",s);
	
	return;
}
