#include <stdio.h>
float main()
{
	float Dola,VND;
	
	printf("Nhap so tien Dola:");
	scanf("%f",&Dola);
	VND=Dola*16689;
	printf("Tien VND la:%f",VND);
	
	return 0;
}
